const nodemailer = require( 'nodemailer' );
require( 'dotenv' ).config();


async function sendMailResetPassWithEmail( recieveremail, messageText, messageHtml, res ) {
    let transporter = await nodemailer.createTransport( {
        host: process.env.HOST_IP,
        port: 25, // 587 or 25 or 2525
        secure: false, // true for 465, false for other ports
        transportMethod: 'SMTP',
        auth: {
            user: process.env.EMAIL_NOREPLY_NAME,
            pass: process.env.EMAIL_NOREPLY_PASS,
        },
        tls: {
            rejectUnauthorized: false,
        },
    } );

    let mail = {
        from: `"Offcampuscareer" <${process.env.EMAIL_NOREPLY_NAME}>`, // sender address
        to: `${recieveremail}`, // list of receivers
        subject: "Reset your password for Offcampuscareer", // Subject line
        text: messageText, // plain text body
        html: messageHtml, // html body
    };
    await transporter.sendMail( mail, function ( err, info ) {
        if ( err ) {
            return res.send( 'Failed to send mail, Please login with different method' );
        } else {
            return res.send( 'success' );
        }
    } );

}

module.exports = {
    sendMailResetPassWithEmail
}