const {
    JobsData,
    InternshipsData,
    ReferralsData,
    ScholarshipsData,
    ForwomenData
} = require( './database/schemas' );
const {
    currencyExchange
} = require( './data/staticData' );
const {
    getJobTimePeriodType,
    uploadToDynamoDB,
    uploadDividedDataToBDs,
    deleteDataFromBothDBsById
} = require( './libraries/normal_functions' );
const {
    uploadDataCourseTable,
    registerUserFunction,
    resetNewPasswordFunction
} = require( './libraries/mysql_functions' );
const {
    tables,
    addOrUpdateData
} = require( './database/dynamoDB' );
const passport = require( 'passport' );
const express = require( 'express' );
const routes = express.Router();
const bcrypt = require( 'bcrypt' );
const saltRounds = 10;

routes.post( '/postEditorial', ( req, res ) => {
    uploadToDynamoDB( tables.names[ 0 ], '/', req, res );
} )

routes.post( '/postCourse', ( req, res ) => {
    let dataObject = req.body;
    uploadDataCourseTable( dataObject );
    res.redirect( '/courses' );
} )

routes.post( '/signinUser', function ( req, res, next ) {
    passport.authenticate( 'local', function ( err, user, info ) {
        if ( err ) {
            return res.send( info.message );
        }
        if ( !user ) {
            return res.send( info.message );
            // return res.redirect( '/signin' );
        }
        req.logIn( user, function ( err ) {
            if ( err ) {
                return res.send( 'Authentication error' );
            }
            return res.send( 'success' );
            // return res.redirect( '/users/' + user.username );
        } );
    } )( req, res, next );
} );

routes.post( '/registerNewUser', async ( req, res ) => {
    let dataObject = req.body;
    dataObject.password = await bcrypt.hash( req.body.password, saltRounds );
    await registerUserFunction( dataObject, res );
} )

routes.post( '/resetNewPassword', async ( req, res ) => {
    let dataObject = req.body;
    dataObject.password = await bcrypt.hash( req.body.password, saltRounds );
    await resetNewPasswordFunction( dataObject, res );
} )

routes.post( '/postExitingForWomens', ( req, res ) => {
    let dataObject = req.body;
    uploadDividedDataToBDs( ForwomenData, tables.names[ 2 ], dataObject );
    res.redirect( '/forwomen' );
} )

routes.post( '/postInternships', ( req, res ) => {
    let newInternship = req.body;
    newInternship = getJobTimePeriodType( newInternship );
    uploadDividedDataToBDs( InternshipsData, tables.names[ 4 ], newInternship );
    res.redirect( '/internships' );
} )

routes.post( '/postJob', ( req, res ) => {
    let dataObject = req.body;
    dataObject = getJobTimePeriodType( dataObject );
    uploadDividedDataToBDs( JobsData, tables.names[ 6 ], dataObject );
    res.redirect( '/jobs' );
} )

routes.post( '/postReferral', ( req, res ) => {
    let dataObject = req.body;
    dataObject = getJobTimePeriodType( dataObject );
    uploadDividedDataToBDs( ReferralsData, tables.names[ 8 ], dataObject );
    res.redirect( '/referral' );
} )

routes.post( '/postScholarship', ( req, res ) => {
    let dataObject = req.body;
    uploadDividedDataToBDs( ScholarshipsData, tables.names[ 10 ], dataObject );
    res.redirect( '/scholarships' );
} )

routes.post( '/deleteDataFromDb', ( req, res ) => {
    let infoObject = req.body;
    deleteDataFromBothDBsById( infoObject );
    res.redirect( `/${infoObject.database}` );
} )

module.exports = routes;